# Sai, Capeta! — Android v1.2-beta

Aplicativo de bloqueio de chamadas **em desenvolvimento**. Identidade visual original aprovada: opção 1 (celular sem chifres segurando escudo dourado e capetinha vermelho assustado); cores vermelho, preto e dourado.

## Funções

- Início: ligar/desligar proteção, contadores, última rejeição, pausa.
- Histórico: números rejeitados, pesquisa, ações para permitir/bloquear, salvar na agenda e excluir.
- Exceções: lista de permitidos e lista de bloqueados, entrada manual e busca de contatos.
- Ajustes: bloqueio normal ou Sossego Absoluto, horário programado, notificações, dados, permissões e **Atualizações**.
- Modo normal rejeita números desconhecidos; Sossego Absoluto libera apenas números na lista de permitidos (exige confirmação).
- Nenhum contato ou histórico é enviado para servidor. Internet é usada exclusivamente quando o usuário verifica/baixa uma atualização.
- Android 10+ (minSdk 29). Não bloqueia WhatsApp/VoIP, nem certos números privados que o sistema não fornece ao filtro.

## Como funciona Atualizações

Na aba **Ajustes > Atualizações**:

1. **Fonte de atualizações**: já vem configurada com o endereço HTTPS do manifesto do repositório público:
   `https://github.com/mais1fraseofc-dot/Sai-Capeta/releases/latest/download/atualizacao.json`
2. **Verificar atualizações**: acessa o JSON, compara `versionCode` e apresenta notas da versão.
3. **Baixar**: baixa o APK por HTTPS, confere SHA-256 antes de disponibilizar a instalação.
4. **Instalar**: abre o instalador do Android, pedindo autorização se necessário. Instalação **nunca** é silenciosa.
5. **Instalar atualização baixada**: aparece após um download bem-sucedido. A versão atualizada preserva dados **se** `applicationId` e certificado de assinatura forem os mesmos.

O aplicativo já aponta para o canal público do repositório `mais1fraseofc-dot/Sai-Capeta`. Enquanto não houver uma primeira versão **release assinada** em GitHub Releases, a verificação responderá que não existe atualização publicada. O botão realiza a consulta real, sem servidor oculto.

### JSON publicado (modelo)

```json
{
  "versionCode": 4,
  "versionName": "1.3",
  "apkUrl": "https://example.org/releases/SaiCapeta-1.3.apk",
  "sha256": "<64 caracteres hexadecimais reais calculados para o APK>",
  "notes": "Novidades e correções."
}
```

A action de publicação cria o manifesto com SHA-256 calculado automaticamente.

## Gerar APK no Android Studio

Requisitos: Android Studio, Android SDK 35, JDK 17, Gradle 8.9, Android Gradle Plugin 8.7.3.

Abra a pasta `SaiCapeta` no Android Studio e selecione **Build > Build APK(s)**. Um APK `debug` estará em `app/build/outputs/apk/debug/app-debug.apk`. Ele serve **somente para testes**. Um APK de testes assinado com a chave debug de um computador/runner pode ser incompatível com o APK release gerado depois e exigir desinstalação.

O ambiente em que este pacote foi criado **não possui Android SDK e não compilou ou testou APK**.

## Publicar APK estável e atualizações pelo GitHub Actions

Incluí dois workflows:
- `.github/workflows/gerar-apk.yml` gera APK **debug de teste**, sem garantia de atualização sobre APKs de outras máquinas.
- `.github/workflows/publicar-atualizacao.yml` gera um APK **release** com assinatura estável e publica o APK e `atualizacao.json` em GitHub Releases.

Para usar a publicação release com atualizações preservando os dados:

1. Crie um repositório GitHub **público** com o conteúdo da pasta `SaiCapeta` na raiz (o código **não** inclui contatos, telefones de usuários ou dados pessoais).
2. **Gere uma chave de assinatura segura apenas uma vez, guarde a chave original e as senhas fora do repositório e mantenha backups protegidos.** Exemplo no computador com JDK:

   ```sh
   keytool -genkeypair -v -keystore saicapeta-release.jks -alias saicapeta -keyalg RSA -keysize 3072 -validity 10000
   base64 -w 0 saicapeta-release.jks
   ```

   No Windows, use uma ferramenta adequada para codificar o arquivo em Base64 sem inserir quebras de linha. **Nunca publique o arquivo `.jks`, o conteúdo Base64 ou suas senhas.**
3. Cadastre estes *GitHub Actions Secrets* no repositório:
   - `SAICAPETA_KEYSTORE_B64`: conteúdo Base64 do `.jks`;
   - `SAICAPETA_KEYSTORE_PASSWORD`: senha da chave-armazenamento;
   - `SAICAPETA_KEY_ALIAS`: alias usado no `keytool` (ex.: `saicapeta`);
   - `SAICAPETA_KEY_PASSWORD`: senha da chave dentro do keystore.
4. Execute **Actions > Publicar atualização Sai Capeta > Run workflow** informando `v1.2` como tag. O workflow gera e assina o APK, cria o JSON com SHA-256 e disponibiliza ambos em Releases. O Android exige autorização para instalar APKs fora da Play Store.
5. Instale **esse APK assinado** e configure, no app, a URL permanente indicada na seção de atualizações, substituindo `SEU_USUARIO` e `SEU_REPOSITORIO`.
6. Nas versões futuras, aumente `versionCode` e `versionName` em `app/build.gradle`, publique uma nova tag (`v1.3`, por exemplo) **com a mesma chave**. O app poderá buscar, baixar e abrir o instalador sem perder suas listas e histórico.

**Nunca altere** `applicationId 'br.com.saicapeta.android'` nem perca a chave de assinatura se pretende atualizar sem desinstalar.

> Atenção: o mecanismo de autoinstalação de APKs é para distribuição particular fora da Play Store. Para publicar na Play Store, utilize o fluxo de atualizações oficial da loja, pois a política do Google Play restringe `REQUEST_INSTALL_PACKAGES` quando não é funcionalidade central.

## Validação antes de considerar a versão pronta

- Testar em Motorola Android 15 e outras versões de interesse.
- Verificar permissões de `READ_CONTACTS`, filtro de chamadas e notificações.
- Testar chamadas de contato salvo, fora da agenda, permitido, bloqueado, chamadas com DDD/55, Sossego Absoluto e horário programado.
- Testar primeiro APK release e segundo APK release assinado com **a mesma** chave, validando manutenção dos dados.
- Testar `atualizacao.json`, conexão sem internet, JSON inválido, SHA-256 incorreto e indisponibilidade do instalador.

Uma instalação de APK pode exigir autorização do Android. Não permita permissões excessivas a apps não confiáveis.
