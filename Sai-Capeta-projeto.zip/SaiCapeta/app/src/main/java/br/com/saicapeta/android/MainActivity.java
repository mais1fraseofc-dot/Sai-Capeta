package br.com.saicapeta.android;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.TimePickerDialog;
import android.app.role.RoleManager;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import org.json.JSONObject;

/** Interface nativa, acessível e sem dependências externas. */
public final class MainActivity extends Activity {
    private static final int REQ_CONTACTS=71, REQ_ROLE=72, REQ_PICK=73, REQ_NOTIFICATIONS=74;
    private static final int BG=Color.rgb(9,7,8), PANEL=Color.rgb(28,21,23);
    private static final int SECOND=Color.rgb(40,29,31), RED=Color.rgb(210,28,32);
    private static final int GOLD=Color.rgb(231,180,88), TEXT=Color.rgb(250,244,238);
    private static final int MUTED=Color.rgb(189,175,169), BORDER=Color.rgb(92,65,53);
    private LinearLayout area;
    private String page="inicio";
    private String search="";
    @Override protected void onCreate(Bundle state){super.onCreate(state);getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);render();}
    @Override protected void onResume(){super.onResume();render();}
    private int dp(int n){return Math.round(n*getResources().getDisplayMetrics().density);}
    private GradientDrawable bg(int color,int radius,int border){
        GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));
        if(border!=0)d.setStroke(dp(1),border);return d;
    }
    private LinearLayout stack(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;}
    private LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    private void gap(LinearLayout l,int height){View v=new View(this);l.addView(v,new LinearLayout.LayoutParams(1,dp(height)));}
    private TextView txt(String value,int size,int color,boolean bold){
        TextView t=new TextView(this);t.setText(value);t.setTextSize(size);t.setTextColor(color);
        t.setLineSpacing(dp(3),1f);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;
    }
    private void line(LinearLayout l){View v=new View(this);v.setBackgroundColor(BORDER);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(1));p.topMargin=dp(12);p.bottomMargin=dp(12);l.addView(v,p);}
    private LinearLayout card(LinearLayout parent){
        LinearLayout l=stack();l.setPadding(dp(17),dp(17),dp(17),dp(17));l.setBackground(bg(PANEL,18,BORDER));
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.bottomMargin=dp(14);parent.addView(l,p);return l;
    }
    private Button button(String value,boolean important){
        Button b=new Button(this);b.setAllCaps(false);b.setText(value);b.setTextSize(14);b.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        b.setTextColor(important?TEXT:GOLD);b.setMinHeight(dp(46));b.setPadding(dp(10),dp(8),dp(10),dp(8));
        b.setBackground(bg(important?RED:SECOND,12,important?0:BORDER));return b;
    }
    private void addButton(LinearLayout parent,String label,boolean important,Runnable action){
        Button b=button(label,important);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(48));
        p.topMargin=dp(7);parent.addView(b,p);b.setOnClickListener(v->action.run());
    }
    private void section(String title){area.addView(txt(title,22,TEXT,true));gap(area,12);}
    private boolean contactsOK(){return checkSelfPermission(Manifest.permission.READ_CONTACTS)==PackageManager.PERMISSION_GRANTED;}
    private boolean roleOK(){RoleManager m=(RoleManager)getSystemService(ROLE_SERVICE);return m!=null && m.isRoleAvailable(RoleManager.ROLE_CALL_SCREENING) && m.isRoleHeld(RoleManager.ROLE_CALL_SCREENING);}
    private void render(){
        if(isFinishing())return;
        LinearLayout base=stack();base.setBackgroundColor(BG);
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.setVerticalScrollBarEnabled(false);
        area=stack();area.setPadding(dp(16),dp(15),dp(16),dp(32));scroll.addView(area);
        base.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        header();
        if("inicio".equals(page))home();
        else if("historico".equals(page))history();
        else if("excecoes".equals(page))exceptions();
        else settings();
        footer(base);
        setContentView(base);
    }
    private void header(){
        LinearLayout top=row();TextView name=txt("SAI, CAPETA!",24,GOLD,true);
        top.addView(name,new LinearLayout.LayoutParams(0,-2,1));
        TextView status=txt(SettingsStore.enabled(this)?"● LIGADO":"○ DESLIGADO",11,
            SettingsStore.enabled(this)?GOLD:MUTED,true);
        top.addView(status);area.addView(top);gap(area,5);
        area.addView(txt("Não tá nos contatos? Sai, capeta!",12,MUTED,false));gap(area,18);
    }
    private void footer(LinearLayout base){
        LinearLayout tabs=row();tabs.setBackgroundColor(PANEL);tabs.setPadding(dp(5),dp(7),dp(5),dp(9));
        String[] labels={"Início","Histórico","Exceções","Ajustes"};
        String[] keys={"inicio","historico","excecoes","ajustes"};
        for(int i=0;i<labels.length;i++){
            final String target=keys[i];boolean chosen=page.equals(target);
            TextView b=txt(labels[i],12,chosen?GOLD:MUTED,chosen);
            b.setGravity(Gravity.CENTER);b.setPadding(dp(4),dp(11),dp(4),dp(11));
            if(chosen)b.setBackground(bg(SECOND,12,0));
            tabs.addView(b,new LinearLayout.LayoutParams(0,dp(49),1));
            b.setOnClickListener(v->{page=target;search="";render();});
        }
        base.addView(tabs);
    }
    private void home(){
        ImageView mascot=new ImageView(this);mascot.setImageResource(R.drawable.mascote_aprovado);
        mascot.setScaleType(ImageView.ScaleType.FIT_CENTER);mascot.setContentDescription("Celular com escudo dourado expulsando capetinha assustado");
        LinearLayout.LayoutParams ip=new LinearLayout.LayoutParams(-1,dp(238));ip.bottomMargin=dp(14);area.addView(mascot,ip);
        LinearLayout control=card(area);LinearLayout top=row();
        LinearLayout words=stack();boolean on=SettingsStore.enabled(this);
        String state=(!on?"PROTEÇÃO DESLIGADA":!roleOK() || !contactsOK()?"FALTA AUTORIZAÇÃO":
            !SettingsStore.workingNow(this)?"PROTEÇÃO EM PAUSA":"PROTEÇÃO ATIVA");
        words.addView(txt(state,15,on?GOLD:MUTED,true));
        gap(words,5);words.addView(txt(on?"O capetinha não passa!":"Toque para proteger suas chamadas",12,MUTED,false));
        top.addView(words,new LinearLayout.LayoutParams(0,-2,1));
        Switch toggle=new Switch(this);toggle.setShowText(false);toggle.setChecked(on);
        toggle.setThumbTintList(ColorStateList.valueOf(on?GOLD:MUTED));
        toggle.setTrackTintList(ColorStateList.valueOf(on?RED:SECOND));
        toggle.setContentDescription("Ativar ou desativar bloqueio de chamadas");
        toggle.setOnCheckedChangeListener((view,checked)->{
            if(!checked){SettingsStore.setEnabled(this,false);render();}
            else startEnable();
        });top.addView(toggle);control.addView(top);gap(control,12);
        if(on && !roleOK())control.addView(txt("Defina este app como filtro de chamadas do Android.",12,GOLD,false));
        if(on && !contactsOK())control.addView(txt("Permita acesso aos contatos para proteger a agenda.",12,GOLD,false));
        if(on && SettingsStore.scheduled(this))control.addView(txt("Horário programado: "+
            SettingsStore.timeLabel(SettingsStore.startMinutes(this))+" às "+SettingsStore.timeLabel(SettingsStore.endMinutes(this)),12,MUTED,false));
        if(on && SettingsStore.pausedUntil(this)>System.currentTimeMillis()){
            addButton(control,"Retomar proteção agora",false,()->{SettingsStore.clearPause(this);render();});
        }
        LinearLayout stats=row();LinearLayout a=stack(),b=stack();
        a.setPadding(dp(8),dp(8),dp(8),dp(8));b.setPadding(dp(8),dp(8),dp(8),dp(8));
        a.addView(txt(""+SettingsStore.today(this),29,GOLD,true));a.addView(txt("Bloqueadas hoje",12,MUTED,false));
        b.addView(txt(""+SettingsStore.total(this),29,RED,true));b.addView(txt("Total bloqueado",12,MUTED,false));
        stats.addView(a,new LinearLayout.LayoutParams(0,-2,1));stats.addView(b,new LinearLayout.LayoutParams(0,-2,1));
        LinearLayout counters=card(area);counters.addView(stats);
        List<JSONObject> history=SettingsStore.history(this);
        if(!history.isEmpty()){
            JSONObject last=history.get(0);gap(counters,8);
            counters.addView(txt("Última rejeição: "+last.optString("number","-")+" • "+date(last.optLong("at")),12,MUTED,false));
        }
        LinearLayout actions=card(area);actions.addView(txt("Acesso rápido",17,TEXT,true));gap(actions,8);
        addButton(actions,"Ver chamadas bloqueadas",false,()->{page="historico";render();});
        addButton(actions,"Adicionar número permitido",true,()->showNumberDialog("allow"));
        addButton(actions,"Pausar proteção temporariamente",false,this::showPauseChoices);
        if(SettingsStore.absolute(this)){
            LinearLayout warn=card(area);warn.addView(txt("SOSSEGO ABSOLUTO ATIVADO",14,GOLD,true));gap(warn,6);
            warn.addView(txt("Apenas números adicionados à lista de permitidos poderão tocar, inclusive se seus contatos estiverem salvos.",12,MUTED,false));
        }
    }
    private void history(){
        section("Histórico de bloqueios");
        LinearLayout summary=card(area);summary.addView(txt(""+SettingsStore.total(this)+" chamadas bloqueadas desde a última redefinição",14,GOLD,true));
        gap(summary,5);summary.addView(txt("O aplicativo mantém os últimos 200 registros no aparelho.",12,MUTED,false));
        EditText filter=new EditText(this);filter.setSingleLine(true);filter.setTextColor(TEXT);filter.setHintTextColor(MUTED);
        filter.setHint("Pesquisar número");filter.setTextSize(15);filter.setPadding(dp(12),dp(8),dp(12),dp(8));filter.setBackground(bg(SECOND,12,BORDER));
        filter.setText(search);area.addView(filter,new LinearLayout.LayoutParams(-1,dp(49)));gap(area,12);
        LinearLayout records=stack();area.addView(records);
        Runnable fill=()->{
            records.removeAllViews();int count=0;
            for(JSONObject entry:SettingsStore.history(this)){
                String n=entry.optString("number","");
                if(!search.isEmpty() && !n.contains(search))continue;
                count++;LinearLayout line=card(records);
                line.addView(txt(n,17,TEXT,true));gap(line,5);
                line.addView(txt(date(entry.optLong("at"))+" • "+entry.optString("reason","Número rejeitado"),12,MUTED,false));
                line.setOnClickListener(v->historyOptions(entry));
            }
            if(count==0)records.addView(txt("Nenhuma chamada para mostrar.",14,MUTED,false));
        };fill.run();
        filter.addTextChangedListener(new TextWatcher(){
            public void beforeTextChanged(CharSequence s,int st,int c,int a){}
            public void onTextChanged(CharSequence s,int st,int before,int count){search=s.toString().trim();fill.run();}
            public void afterTextChanged(Editable e){}
        });
        if(!SettingsStore.history(this).isEmpty())addButton(area,"Limpar histórico",false,()->confirm("Apagar registros?","Essa operação não altera a lista de números nem o total de chamadas bloqueadas.",()->{SettingsStore.clearHistory(this);search="";render();}));
    }
    private String date(long time){return new SimpleDateFormat("dd/MM/yyyy HH:mm",Locale.getDefault()).format(new Date(time));}
    private void historyOptions(JSONObject e){
        String number=e.optString("number","");
        String[] choices={"Copiar número","Permitir esse número","Bloquear sempre","Salvar nos contatos","Excluir registro"};
        new AlertDialog.Builder(this).setTitle(number).setItems(choices,(dialog,choice)->{
            if(choice==0){ClipboardManager c=(ClipboardManager)getSystemService(CLIPBOARD_SERVICE);c.setPrimaryClip(ClipData.newPlainText("Número",number));}
            if(choice==1||choice==2){String group=choice==1?"allow":"deny";SettingsStore.add(this,group,number);render();}
            if(choice==3){Intent i=new Intent(ContactsContract.Intents.Insert.ACTION);
                i.setType(ContactsContract.RawContacts.CONTENT_TYPE);i.putExtra(ContactsContract.Intents.Insert.PHONE,number);
                try{startActivity(i);}catch(Exception ex){showInfo("Agenda indisponível","Não foi possível abrir o aplicativo de contatos.");}}
            if(choice==4)confirm("Excluir registro?","O total acumulado será mantido.",()->{SettingsStore.deleteHistoryItem(this,e.optLong("at"));render();});
        }).show();
    }
    private void exceptions(){
        section("Exceções");
        LinearLayout info=card(area);info.addView(txt("Seus contatos são permitidos no modo normal, exceto os números da lista de bloqueio.",13,MUTED,false));
        gap(info,8);info.addView(txt("No Sossego Absoluto, somente a lista de permitidos passa.",13,GOLD,true));
        listPanel("NÚMEROS PERMITIDOS","allow");
        listPanel("BLOQUEIO MANUAL","deny");
    }
    private void listPanel(String title,String which){
        LinearLayout panel=card(area);panel.addView(txt(title,16,GOLD,true));gap(panel,8);
        List<String> items=SettingsStore.list(this,which);
        if(items.isEmpty())panel.addView(txt("Nenhum número cadastrado.",13,MUTED,false));
        for(String number:items){
            LinearLayout r=row();TextView t=txt(number,15,TEXT,true);r.addView(t,new LinearLayout.LayoutParams(0,-2,1));
            Button remove=button("Remover",false);r.addView(remove,new LinearLayout.LayoutParams(dp(95),dp(43)));
            remove.setOnClickListener(v->confirm("Remover número?",number,()->{SettingsStore.remove(this,which,number);render();}));
            gap(panel,5);panel.addView(r);line(panel);
        }
        addButton(panel,which.equals("allow")?"+ Permitir um número":"+ Bloquear um número",true,()->showNumberDialog(which));
        if(which.equals("allow"))addButton(panel,"Escolher da agenda",false,()->{
            Intent pick=new Intent(Intent.ACTION_PICK,ContactsContract.CommonDataKinds.Phone.CONTENT_URI);
            try{startActivityForResult(pick,REQ_PICK);}catch(Exception e){showInfo("Agenda indisponível","Não foi possível abrir a lista de contatos.");}
        });
    }
    private void showNumberDialog(String which){
        EditText input=new EditText(this);input.setHint("Ex.: (15) 99999-9999");input.setInputType(InputType.TYPE_CLASS_PHONE);
        input.setTextSize(17);input.setSingleLine(true);input.setTextColor(TEXT);
        LinearLayout wrap=stack();wrap.setPadding(dp(18),dp(8),dp(18),dp(2));wrap.addView(input);
        new AlertDialog.Builder(this).setTitle(which.equals("allow")?"Permitir número":"Bloquear número")
            .setMessage("Informe o telefone com DDD. Pode incluir +55.").setView(wrap)
            .setNegativeButton("Cancelar",null).setPositiveButton("Salvar",(d,w)->{
                if(!SettingsStore.add(this,which,input.getText().toString()))
                    showInfo("Número não adicionado","Confira os dígitos ou veja se ele já está cadastrado.");
                else render();
            }).show();
    }
    private void settings(){
        section("Configurações");
        LinearLayout modes=card(area);modes.addView(txt("Modo de proteção",18,GOLD,true));gap(modes,9);
        modes.addView(txt(SettingsStore.absolute(this)?"Atual: SOSSEGO ABSOLUTO":"Atual: BLOQUEIO NORMAL",14,TEXT,true));gap(modes,7);
        modes.addView(txt("Normal: libera contatos e permitidos, bloqueia desconhecidos e proibidos.",12,MUTED,false));gap(modes,7);
        modes.addView(txt("Sossego Absoluto: só os números explicitamente permitidos conseguem tocar.",12,MUTED,false));
        addButton(modes,SettingsStore.absolute(this)?"Voltar ao modo normal":"Ativar Sossego Absoluto",true,()->{
            if(SettingsStore.absolute(this)){SettingsStore.setAbsolute(this,false);render();return;}
            int size=SettingsStore.list(this,"allow").size();
            confirm("Ativar Sossego Absoluto?","Mesmo pessoas salvas nos contatos serão bloqueadas se não estiverem na lista de permitidos. Atualmente há "+size+" número(s) permitido(s). Retornos de serviços importantes também podem ser rejeitados.",()->{SettingsStore.setAbsolute(this,true);render();});
        });
        LinearLayout schedule=card(area);schedule.addView(txt("Horário programado",18,GOLD,true));gap(schedule,8);
        schedule.addView(txt("A proteção funciona somente no intervalo configurado. Horários iguais significam 24 horas.",12,MUTED,false));
        Switch scheduleToggle=switchItem("Usar programação",SettingsStore.scheduled(this),b->{SettingsStore.setScheduled(this,b);render();});
        schedule.addView(scheduleToggle);gap(schedule,6);
        addButton(schedule,"Início: "+SettingsStore.timeLabel(SettingsStore.startMinutes(this)),false,()->pickTime(true));
        addButton(schedule,"Fim: "+SettingsStore.timeLabel(SettingsStore.endMinutes(this)),false,()->pickTime(false));
        LinearLayout pause=card(area);pause.addView(txt("Pausa temporária",18,GOLD,true));gap(pause,6);
        pause.addView(txt("Durante a pausa, as chamadas não serão rejeitadas pelo Sai, Capeta!",12,MUTED,false));
        addButton(pause,"Pausar por 30 min, 1 h ou 2 h",false,this::showPauseChoices);
        if(SettingsStore.pausedUntil(this)>System.currentTimeMillis())addButton(pause,"Cancelar pausa",true,()->{SettingsStore.clearPause(this);render();});
        LinearLayout alerts=card(area);alerts.addView(txt("Avisos",18,GOLD,true));gap(alerts,7);
        alerts.addView(txt("Receber um aviso discreto quando uma chamada for bloqueada.",12,MUTED,false));
        alerts.addView(switchItem("Notificar bloqueios",SettingsStore.notifications(this),b->{
            if(b && Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                !=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},REQ_NOTIFICATIONS);}
            else{SettingsStore.setNotifications(this,b);render();}
        }));
        LinearLayout permission=card(area);permission.addView(txt("Permissões e segurança",18,GOLD,true));gap(permission,7);
        permission.addView(txt("Agenda: "+(contactsOK()?"autorizada":"pendente"),13,MUTED,false));
        permission.addView(txt("Filtro de chamadas: "+(roleOK()?"autorizado":"pendente"),13,MUTED,false));
        addButton(permission,"Autorizar e ativar proteção",true,this::startEnable);
        gap(permission,9);permission.addView(txt("Sem anúncios. A internet é usada somente para verificar ou baixar atualizações quando solicitado; contatos e histórico não são enviados.",12,MUTED,false));
        LinearLayout updates=card(area);updates.addView(txt("Atualizações",18,GOLD,true));gap(updates,8);
        updates.addView(txt("Versão instalada: "+UpdateManager.installedName(this)+" ("+UpdateManager.installedCode(this)+")",13,TEXT,true));gap(updates,5);
        String channel=UpdateManager.source(this);
        updates.addView(txt(channel.isEmpty()?"Canal de atualização ainda não configurado.":"Canal de atualização: "+channel,12,MUTED,false));
        addButton(updates,"Verificar atualizações",true,()->UpdateManager.check(this));
        addButton(updates,"Configurar fonte de atualizações",false,()->UpdateManager.editSource(this));
        if(UpdateManager.hasDownloaded(this))addButton(updates,"Instalar atualização baixada",false,()->UpdateManager.install(this));
        updates.addView(txt("Download protegido por HTTPS e verificação SHA-256. A instalação sempre exige sua confirmação.",12,MUTED,false));
        LinearLayout data=card(area);data.addView(txt("Dados do aplicativo",18,GOLD,true));
        addButton(data,"Limpar histórico",false,()->confirm("Limpar histórico?","Apaga somente os registros individuais.",()->{SettingsStore.clearHistory(this);render();}));
        addButton(data,"Zerar contador total",false,()->confirm("Zerar contador?","O histórico permanecerá disponível.",()->{SettingsStore.resetTotal(this);render();}));
        gap(area,9);
        area.addView(txt("Sai, Capeta! • versão 1.2 beta",11,MUTED,false));gap(area,8);
        area.addView(txt("Chamadas de WhatsApp e números privados que o Android não encaminha ao filtro não são bloqueados por este aplicativo.",12,MUTED,false));
    }
    private Switch switchItem(String title,boolean value,java.util.function.Consumer<Boolean> callback){
        Switch sw=new Switch(this);sw.setText(title);sw.setTextColor(TEXT);sw.setTextSize(14);
        sw.setPadding(dp(1),dp(12),dp(1),dp(12));sw.setChecked(value);
        sw.setThumbTintList(ColorStateList.valueOf(value?GOLD:MUTED));
        sw.setOnCheckedChangeListener((v,checked)->callback.accept(checked));return sw;
    }
    private void pickTime(boolean start){
        int current=start?SettingsStore.startMinutes(this):SettingsStore.endMinutes(this);
        new TimePickerDialog(this,(picker,hour,minute)->{
            if(start)SettingsStore.setStart(this,hour*60+minute);else SettingsStore.setEnd(this,hour*60+minute);
            render();
        },current/60,current%60,true).show();
    }
    private void showPauseChoices(){
        String[] choices={"30 minutos","1 hora","2 horas","Retomar agora"};
        new AlertDialog.Builder(this).setTitle("Pausar a proteção").setItems(choices,(d,choice)->{
            if(choice==3)SettingsStore.clearPause(this);
            else{long[] duration={30*60_000L,60*60_000L,120*60_000L};SettingsStore.pauseFor(this,duration[choice]);}
            render();
        }).show();
    }
    private void confirm(String title,String message,Runnable yes){
        new AlertDialog.Builder(this).setTitle(title).setMessage(message)
            .setNegativeButton("Cancelar",null).setPositiveButton("Confirmar",(d,w)->yes.run()).show();
    }
    private void showInfo(String title,String message){new AlertDialog.Builder(this).setTitle(title).setMessage(message).setPositiveButton("OK",null).show();}
    private void startEnable(){
        if(!contactsOK()){
            new AlertDialog.Builder(this).setTitle("Acesso aos contatos")
                .setMessage("O Sai, Capeta! precisa identificar seus contatos para não bloquear conhecidos no modo normal. A agenda não sai do aparelho.")
                .setNegativeButton("Agora não",(d,w)->render())
                .setPositiveButton("Permitir",(d,w)->requestPermissions(new String[]{Manifest.permission.READ_CONTACTS},REQ_CONTACTS)).show();
            return;
        }
        requestRole();
    }
    private void requestRole(){
        RoleManager m=(RoleManager)getSystemService(ROLE_SERVICE);
        if(m==null || !m.isRoleAvailable(RoleManager.ROLE_CALL_SCREENING)){
            showInfo("Filtro indisponível","O Android não disponibilizou o papel de filtro de chamadas neste aparelho.");render();return;
        }
        if(m.isRoleHeld(RoleManager.ROLE_CALL_SCREENING)){
            SettingsStore.setEnabled(this,true);render();return;
        }
        startActivityForResult(m.createRequestRoleIntent(RoleManager.ROLE_CALL_SCREENING),REQ_ROLE);
    }
    @Override public void onRequestPermissionsResult(int requestCode,String[] permissions,int[] grants){
        super.onRequestPermissionsResult(requestCode,permissions,grants);
        boolean success=grants.length>0 && grants[0]==PackageManager.PERMISSION_GRANTED;
        if(requestCode==REQ_CONTACTS){if(success)requestRole();else render();}
        if(requestCode==REQ_NOTIFICATIONS){SettingsStore.setNotifications(this,success);render();}
    }
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode==REQ_ROLE){if(resultCode==RESULT_OK && roleOK() && contactsOK())SettingsStore.setEnabled(this,true);render();}
        if(requestCode==REQ_PICK){
            if(resultCode==RESULT_OK && data!=null && data.getData()!=null){
                try(android.database.Cursor c=getContentResolver().query(data.getData(),
                    new String[]{ContactsContract.CommonDataKinds.Phone.NUMBER},null,null,null)) {
                    if(c!=null && c.moveToFirst()){
                        String n=c.getString(0);
                        if(!SettingsStore.add(this,"allow",n))showInfo("Não adicionado","Esse número já está permitido ou não é válido.");
                    }
                }catch(Exception e){showInfo("Não foi possível importar","Adicione o número manualmente.");}
            }
            render();
        }
    }
}
