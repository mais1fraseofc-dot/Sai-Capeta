package br.com.saicapeta.android;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.provider.OpenableColumns;
import java.io.File;
import java.io.FileNotFoundException;

/** Compartilha exclusivamente o APK validado com o instalador do Android. */
public final class UpdateApkProvider extends ContentProvider {
    public static final String AUTHORITY="br.com.saicapeta.android.updates";
    public static final Uri CONTENT_URI=Uri.parse("content://"+AUTHORITY+"/apk/current");
    @Override public boolean onCreate(){return true;}
    private File onlyAllowed(Uri uri) throws FileNotFoundException {
        if(!CONTENT_URI.equals(uri) || getContext()==null)throw new FileNotFoundException("Caminho inválido");
        File f=new File(new File(getContext().getFilesDir(),"updates"),"SaiCapeta-atualizacao.apk");
        if(!f.isFile())throw new FileNotFoundException("Atualização não encontrada");
        return f;
    }
    @Override public ParcelFileDescriptor openFile(Uri uri,String mode) throws FileNotFoundException {
        if(!"r".equals(mode))throw new FileNotFoundException("Somente leitura");
        return ParcelFileDescriptor.open(onlyAllowed(uri),ParcelFileDescriptor.MODE_READ_ONLY);
    }
    @Override public Cursor query(Uri uri,String[] projection,String selection,String[] selectionArgs,String sortOrder){
        try {
            File f=onlyAllowed(uri);
            String[] cols=projection==null?new String[]{OpenableColumns.DISPLAY_NAME,OpenableColumns.SIZE}:projection;
            MatrixCursor cursor=new MatrixCursor(cols);
            Object[] vals=new Object[cols.length];
            for(int i=0;i<cols.length;i++){
                if(OpenableColumns.DISPLAY_NAME.equals(cols[i]))vals[i]=f.getName();
                else if(OpenableColumns.SIZE.equals(cols[i]))vals[i]=f.length();
                else vals[i]=null;
            }
            cursor.addRow(vals);return cursor;
        }catch(FileNotFoundException e){return null;}
    }
    @Override public String getType(Uri uri){return "application/vnd.android.package-archive";}
    @Override public Uri insert(Uri uri,ContentValues values){throw new UnsupportedOperationException();}
    @Override public int delete(Uri uri,String selection,String[] selectionArgs){throw new UnsupportedOperationException();}
    @Override public int update(Uri uri,ContentValues values,String selection,String[] selectionArgs){throw new UnsupportedOperationException();}
}
