package br.com.saicapeta.android;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.provider.ContactsContract;
import android.telecom.Call;
import android.telecom.CallScreeningService;

/** Filtro nativo de chamadas telefônicas. Falha segura: em dúvida, deixa tocar. */
public final class SaiCapetaCallScreeningService extends CallScreeningService {
    @Override public void onScreenCall(Call.Details details) {
        if(details.getCallDirection()!=Call.Details.DIRECTION_INCOMING)return;
        boolean reject=false;
        String number=null,reason="";
        try {
            if(SettingsStore.workingNow(this)
                && checkSelfPermission(Manifest.permission.READ_CONTACTS)==PackageManager.PERMISSION_GRANTED) {
                Uri handle=details.getHandle();
                if(handle!=null && "tel".equalsIgnoreCase(handle.getScheme())) {
                    number=handle.getSchemeSpecificPart();
                    if(number!=null && !number.trim().isEmpty()) {
                        if(SettingsStore.contains(this,"deny",number)){
                            reject=true;reason="Lista de bloqueados";
                        } else if(SettingsStore.contains(this,"allow",number)) {
                            reject=false;
                        } else if(SettingsStore.absolute(this)) {
                            reject=true;reason="Sossego Absoluto";
                        } else {
                            Boolean inContacts=isContact(number);
                            if(Boolean.FALSE.equals(inContacts)){
                                reject=true;reason="Fora dos contatos";
                            }
                        }
                    }
                }
            }
        } catch(Exception ignored) {reject=false;}
        CallResponse response=new CallResponse.Builder()
            .setDisallowCall(reject).setRejectCall(reject)
            .setSkipCallLog(false).setSkipNotification(reject).build();
        respondToCall(details,response);
        if(reject && number!=null){
            try {SettingsStore.record(this,number,reason);}catch(Exception ignored){}
            if(SettingsStore.notifications(this))notifyBlock(number);
        }
    }
    /** null = falha de consulta, não rejeitar. */
    private Boolean isContact(String number){
        Uri uri=Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI,Uri.encode(number));
        try(Cursor cursor=getContentResolver().query(uri,
             new String[]{ContactsContract.PhoneLookup._ID},null,null,null)) {
            return cursor==null ? null : cursor.moveToFirst();
        }catch(Exception e){return null;}
    }
    private void notifyBlock(String number){
        try {
            if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                !=PackageManager.PERMISSION_GRANTED)return;
            NotificationManager m=getSystemService(NotificationManager.class);
            if(m==null)return;
            String channel="chamadas_bloqueadas";
            m.createNotificationChannel(new NotificationChannel(channel,"Chamadas bloqueadas",
                 NotificationManager.IMPORTANCE_LOW));
            Notification n=new Notification.Builder(this,channel)
                .setSmallIcon(android.R.drawable.ic_menu_call)
                .setContentTitle("Sai, Capeta! expulsou uma chamada")
                .setContentText("Número bloqueado: "+number)
                .setVisibility(Notification.VISIBILITY_PRIVATE)
                .setAutoCancel(true).build();
            m.notify((int)(System.currentTimeMillis()%Integer.MAX_VALUE),n);
        }catch(Exception ignored){}
    }
}
