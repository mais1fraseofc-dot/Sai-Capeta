package br.com.saicapeta.android;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;
import android.telephony.PhoneNumberUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

/** Dados locais. Sem servidor, analytics, permissões de rede ou upload de contatos. */
public final class SettingsStore {
    private static final String FILE = "sai_capeta_local_v1";
    private static final int LIMIT = 200;
    private SettingsStore() {}
    private static SharedPreferences prefs(Context c) {return c.getSharedPreferences(FILE, Context.MODE_PRIVATE);}
    public static boolean enabled(Context c) {return prefs(c).getBoolean("enabled",false);}
    public static void setEnabled(Context c, boolean b) {prefs(c).edit().putBoolean("enabled",b).apply();}
    public static boolean absolute(Context c) {return prefs(c).getBoolean("absolute",false);}
    public static void setAbsolute(Context c, boolean b) {prefs(c).edit().putBoolean("absolute",b).apply();}
    public static boolean notifications(Context c) {return prefs(c).getBoolean("notifications",false);}
    public static void setNotifications(Context c, boolean b) {prefs(c).edit().putBoolean("notifications",b).apply();}
    public static long pausedUntil(Context c) {return prefs(c).getLong("paused_until",0L);}
    public static void pauseFor(Context c, long millis) {prefs(c).edit().putLong("paused_until", System.currentTimeMillis()+millis).apply();}
    public static void clearPause(Context c) {prefs(c).edit().putLong("paused_until",0L).apply();}
    public static boolean scheduled(Context c) {return prefs(c).getBoolean("scheduled",false);}
    public static void setScheduled(Context c,boolean b) {prefs(c).edit().putBoolean("scheduled",b).apply();}
    public static int startMinutes(Context c) {return prefs(c).getInt("start_minutes",22*60);}
    public static int endMinutes(Context c) {return prefs(c).getInt("end_minutes",7*60);}
    public static void setStart(Context c,int minutes){prefs(c).edit().putInt("start_minutes",minutes).apply();}
    public static void setEnd(Context c,int minutes){prefs(c).edit().putInt("end_minutes",minutes).apply();}
    public static String timeLabel(int minutes){return String.format(Locale.getDefault(),"%02d:%02d",minutes/60,minutes%60);}
    public static boolean isWithinSchedule(Context c) {
        if (!scheduled(c)) return true;
        int start=startMinutes(c), end=endMinutes(c);
        if (start==end) return true; // 24h
        Calendar now=Calendar.getInstance();
        int minute=now.get(Calendar.HOUR_OF_DAY)*60+now.get(Calendar.MINUTE);
        return start<end ? (minute>=start && minute<end) : (minute>=start || minute<end);
    }
    public static boolean workingNow(Context c) {
        return enabled(c) && System.currentTimeMillis()>=pausedUntil(c) && isWithinSchedule(c);
    }
    public static int total(Context c) {return prefs(c).getInt("total",0);}
    public static void resetTotal(Context c) {prefs(c).edit().putInt("total",0).apply();}
    private static JSONArray parse(String s) {try{return new JSONArray(s);}catch(Exception e){return new JSONArray();}}
    public static String clean(String raw) {return raw==null?"":PhoneNumberUtils.normalizeNumber(raw.trim());}
    public static boolean same(String a,String b){
        if(a==null || b==null) return false;
        if(Build.VERSION.SDK_INT>=31) {
            String region=Locale.getDefault().getCountry();
            if(region.isEmpty()) region="BR";
            return PhoneNumberUtils.areSamePhoneNumber(a,b,region);
        }
        return PhoneNumberUtils.compare(a,b);
    }
    public static List<String> list(Context c,String which){
        if(!which.equals("allow") && !which.equals("deny"))return new ArrayList<>();
        JSONArray array=parse(prefs(c).getString(which,"[]"));
        List<String> out=new ArrayList<>();
        for(int i=0;i<array.length();i++){String n=array.optString(i,"");if(!n.isEmpty())out.add(n);}
        return out;
    }
    public static boolean contains(Context c,String which,String number){
        for(String n:list(c,which)) if(same(n,number))return true;
        return false;
    }
    public static boolean add(Context c,String which,String raw){
        if(!which.equals("allow") && !which.equals("deny"))return false;
        String n=clean(raw);
        if(n.replaceAll("\\D","").length()<8 || contains(c,which,n))return false;
        // Uma regra nova prevalece: remover da lista oposta.
        remove(c,which.equals("allow")?"deny":"allow",n);
        List<String> entries=list(c,which);entries.add(n);
        JSONArray a=new JSONArray();for(String s:entries)a.put(s);
        prefs(c).edit().putString(which,a.toString()).apply();
        return true;
    }
    public static void remove(Context c,String which,String raw){
        if(!which.equals("allow") && !which.equals("deny"))return;
        JSONArray a=new JSONArray();
        for(String n:list(c,which)) if(!same(n,raw))a.put(n);
        prefs(c).edit().putString(which,a.toString()).apply();
    }
    public static List<JSONObject> history(Context c){
        JSONArray a=parse(prefs(c).getString("history","[]"));
        List<JSONObject> out=new ArrayList<>();
        for(int i=0;i<a.length();i++){JSONObject item=a.optJSONObject(i);if(item!=null)out.add(item);}
        return out;
    }
    private static String todayKey(){
        Calendar cal=Calendar.getInstance();
        return cal.get(Calendar.YEAR)+"-"+(cal.get(Calendar.MONTH)+1)+"-"+cal.get(Calendar.DAY_OF_MONTH);
    }
    public static int today(Context c){
        SharedPreferences p=prefs(c);
        return todayKey().equals(p.getString("today_key",""))?p.getInt("today_total",0):0;
    }
    public static synchronized void record(Context c,String number,String reason){
        SharedPreferences p=prefs(c);
        JSONArray previous=parse(p.getString("history","[]"));
        JSONArray out=new JSONArray();
        JSONObject e=new JSONObject();
        try{e.put("number",number);e.put("reason",reason);e.put("at",System.currentTimeMillis());}catch(Exception ignored){}
        out.put(e);
        for(int i=0;i<previous.length() && i<LIMIT-1;i++){
            JSONObject item=previous.optJSONObject(i);if(item!=null)out.put(item);
        }
        String day=todayKey();
        int count=day.equals(p.getString("today_key",""))?p.getInt("today_total",0):0;
        p.edit().putString("history",out.toString())
            .putInt("total",p.getInt("total",0)+1)
            .putString("today_key",day).putInt("today_total",count+1).commit();
    }
    public static void deleteHistoryItem(Context c,long at){
        JSONArray a=new JSONArray();for(JSONObject item:history(c))if(item.optLong("at")!=at)a.put(item);
        prefs(c).edit().putString("history",a.toString()).apply();
    }
    public static void clearHistory(Context c){prefs(c).edit().putString("history","[]").apply();}
}
