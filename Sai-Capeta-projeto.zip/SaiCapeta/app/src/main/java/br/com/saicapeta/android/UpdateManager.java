package br.com.saicapeta.android;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.InputType;
import android.widget.EditText;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.MessageDigest;
import java.util.Locale;
import org.json.JSONObject;

/** Atualização voluntária: HTTPS -> manifesto -> APK + SHA-256 -> instalador Android. */
public final class UpdateManager {
    private static final String STORE="sai_capeta_updates";
    private static final String DEFAULT_SOURCE="https://github.com/mais1fraseofc-dot/Sai-Capeta/releases/latest/download/atualizacao.json";
    private static final int MAX_JSON=32768;
    private static final long MAX_APK=150L*1024*1024;
    private static final Handler UI=new Handler(Looper.getMainLooper());
    private UpdateManager(){}
    public interface Callback {void done(boolean ok,String detail);}
    public static String source(Context c){return c.getSharedPreferences(STORE,0).getString("manifestUrl",DEFAULT_SOURCE);}
    public static void saveSource(Context c,String s){c.getSharedPreferences(STORE,0).edit().putString("manifestUrl",s.trim()).apply();}
    public static boolean validHttps(String u){
        try {Uri uri=Uri.parse(u);return "https".equalsIgnoreCase(uri.getScheme())
            && uri.getHost()!=null && !uri.getHost().trim().isEmpty() && uri.getUserInfo()==null;}
        catch(Exception ex){return false;}
    }
    public static int installedCode(Context c){
        try {PackageInfo pkg=c.getPackageManager().getPackageInfo(c.getPackageName(),0);
             return (int)(Build.VERSION.SDK_INT>=28?pkg.getLongVersionCode():pkg.versionCode);}
        catch(Exception e){return -1;}
    }
    public static String installedName(Context c){
        try {return c.getPackageManager().getPackageInfo(c.getPackageName(),0).versionName;}
        catch(Exception e){return "?";}
    }
    private static final class Release {
        int code;String name,apkUrl,sha,notes;
        Release(JSONObject j)throws Exception {
            code=j.getInt("versionCode");name=j.getString("versionName");
            apkUrl=j.getString("apkUrl");sha=j.getString("sha256").trim().toLowerCase(Locale.ROOT);
            notes=j.optString("notes","");
            if(code<=0 || !validHttps(apkUrl)||!sha.matches("[0-9a-f]{64}"))
                throw new Exception("Manifesto inválido. Verifique versão, endereço HTTPS e SHA-256.");
        }
    }
    private static HttpURLConnection openHttps(String url)throws Exception {
        // GitHub Releases usa redirecionamentos HTTPS para servir os arquivos.
        for(int hop=0;hop<6;hop++){
            if(!validHttps(url))throw new Exception("Só são permitidos endereços HTTPS.");
            HttpURLConnection con=(HttpURLConnection)new URL(url).openConnection();
            con.setInstanceFollowRedirects(false);
            con.setConnectTimeout(10000);con.setReadTimeout(25000);
            con.setRequestProperty("Accept","application/json,application/octet-stream");
            int code=con.getResponseCode();
            if(code==200)return con;
            if(code==301||code==302||code==303||code==307||code==308){
                String location=con.getHeaderField("Location");
                if(location==null)throw new Exception("Redirecionamento sem endereço.");
                url=new URL(new URL(url),location).toString();con.disconnect();continue;
            }
            con.disconnect();throw new Exception("Servidor respondeu HTTP "+code+". Verifique o canal de atualizações.");
        }
        throw new Exception("Redirecionamentos em excesso.");
    }
    private static String readJSON(InputStream in)throws Exception {
        ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] buffer=new byte[2048];int n;
        while((n=in.read(buffer))!=-1){out.write(buffer,0,n);if(out.size()>MAX_JSON)throw new Exception("Manifesto muito grande.");}
        return out.toString("UTF-8");
    }
    public static void check(Activity a){
        String url=source(a);
        if(url.isEmpty()){editSource(a);return;}
        if(!validHttps(url)){message(a,"Canal inválido","Configure um endereço HTTPS de atualização.");return;}
        AlertDialog loading=new AlertDialog.Builder(a).setTitle("Verificando atualizações")
            .setMessage("Consultando o canal configurado…").setCancelable(false).create();loading.show();
        new Thread(()->{
            HttpURLConnection c=null;
            try {c=openHttps(url);String raw;try(InputStream in=c.getInputStream()){raw=readJSON(in);}
                Release rel=new Release(new JSONObject(raw));
                UI.post(()->{loading.dismiss();if(rel.code<=installedCode(a)){
                    message(a,"Tudo em dia","Você já possui a versão mais recente disponível neste canal ("+installedName(a)+").");
                }else{
                    String notes=rel.notes.isEmpty()?"Correções e melhorias.":rel.notes;
                    new AlertDialog.Builder(a).setTitle("Nova versão: "+rel.name)
                        .setMessage(notes+"\n\nBaixar e instalar agora? Seus dados são mantidos quando a atualização usa a mesma assinatura digital.")
                        .setNegativeButton("Depois",null)
                        .setPositiveButton("Baixar",(d,w)->download(a,rel)).show();
                }});
            }catch(Exception e){String msg=e.getMessage();UI.post(()->{loading.dismiss();message(a,"Não foi possível verificar",msg);});}
            finally{if(c!=null)c.disconnect();}
        },"update-check").start();
    }
    private static File target(Context c){return new File(new File(c.getFilesDir(),"updates"),"SaiCapeta-atualizacao.apk");}
    public static boolean hasDownloaded(Context c){return target(c).isFile() && target(c).length()>0;}
    private static void download(Activity a,Release rel){
        AlertDialog loading=new AlertDialog.Builder(a).setTitle("Baixando versão "+rel.name)
            .setMessage("Conferindo a integridade do arquivo após baixar. Não feche o app.")
            .setCancelable(false).create();loading.show();
        new Thread(()->{
            HttpURLConnection c=null;File partial=null;
            try {
                c=openHttps(rel.apkUrl);
                long contentLength=c.getContentLengthLong();
                if(contentLength>MAX_APK)throw new Exception("Arquivo maior que 150 MB.");
                File dest=target(a);if(!dest.getParentFile().exists() && !dest.getParentFile().mkdirs())
                    throw new Exception("Não foi possível criar a pasta de atualizações.");
                partial=new File(dest.getParentFile(),"download.tmp");
                MessageDigest dig=MessageDigest.getInstance("SHA-256");long size=0;
                try(InputStream in=new BufferedInputStream(c.getInputStream());
                    FileOutputStream output=new FileOutputStream(partial);
                    BufferedOutputStream out=new BufferedOutputStream(output)){
                    byte[] buffer=new byte[16384];int n;
                    while((n=in.read(buffer))!=-1){size+=n;if(size>MAX_APK)throw new Exception("Arquivo maior que 150 MB.");
                        out.write(buffer,0,n);dig.update(buffer,0,n);}
                }
                if(size<10000)throw new Exception("Arquivo APK incompleto.");
                StringBuilder hash=new StringBuilder();for(byte b:dig.digest())hash.append(String.format(Locale.ROOT,"%02x",b&255));
                if(!hash.toString().equals(rel.sha))throw new Exception("Assinatura de integridade SHA-256 não confere. O arquivo foi descartado.");
                // Evita conservar um APK anterior caso esta substituição falhe.
                if(dest.exists() && !dest.delete())throw new Exception("Não foi possível substituir o APK antigo.");
                if(!partial.renameTo(dest))throw new Exception("Não foi possível finalizar o download.");
                UI.post(()->{loading.dismiss();new AlertDialog.Builder(a)
                    .setTitle("Download verificado")
                    .setMessage("APK íntegro, pronto para o instalador do Android. Você precisará confirmar a instalação.")
                    .setPositiveButton("Instalar",(d,w)->install(a))
                    .setNegativeButton("Depois",null).show();});
            }catch(Exception e){if(partial!=null)partial.delete();String msg=e.getMessage();
                UI.post(()->{loading.dismiss();message(a,"Falha ao baixar",msg);});}
            finally{if(c!=null)c.disconnect();}
        },"update-download").start();
    }
    public static void install(Activity a){
        if(!hasDownloaded(a)){message(a,"Nenhum APK","Verifique e baixe uma atualização antes de instalar.");return;}
        if(Build.VERSION.SDK_INT>=26 && !a.getPackageManager().canRequestPackageInstalls()){
            new AlertDialog.Builder(a).setTitle("Autorizar instalação")
                .setMessage("O Android precisa que você autorize esta fonte para instalar o APK baixado. Depois volte ao Sai, Capeta! e toque em 'Instalar atualização baixada'.")
                .setNegativeButton("Cancelar",null)
                .setPositiveButton("Abrir configurações",(d,w)->{
                    Intent i=new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                        Uri.parse("package:"+a.getPackageName()));
                    try{a.startActivity(i);}catch(Exception e){message(a,"Configurações","Abra as configurações de aplicativos para permitir esta instalação.");}
                }).show();return;
        }
        try {
            Intent i=new Intent(Intent.ACTION_VIEW);
            i.setDataAndType(UpdateApkProvider.CONTENT_URI,"application/vnd.android.package-archive");
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            a.startActivity(i);
        }catch(Exception e){message(a,"Instalador indisponível","Não foi possível abrir o instalador do Android neste dispositivo.");}
    }
    public static void editSource(Activity a){
        EditText field=new EditText(a);field.setSingleLine(false);field.setMinLines(2);
        field.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_URI);
        field.setText(source(a));field.setSelectAllOnFocus(true);
        field.setTextSize(13);
        field.setHint("https://seu-site.com/atualizacao.json");
        android.widget.LinearLayout wrap=new android.widget.LinearLayout(a);
        wrap.setPadding(32,8,32,8);wrap.addView(field);
        new AlertDialog.Builder(a).setTitle("Fonte de atualizações")
            .setMessage("Informe o endereço HTTPS do manifesto de versões que publicaremos. Sem um servidor configurado, o aplicativo não consegue descobrir novas versões sozinho.")
            .setView(wrap).setNegativeButton("Cancelar",null)
            .setNeutralButton("Limpar",(d,w)->{saveSource(a,"");message(a,"Canal removido","Você pode configurá-lo novamente quando publicar as próximas versões.");})
            .setPositiveButton("Salvar",(d,w)->{
                String u=field.getText().toString().trim();
                if(!validHttps(u)){message(a,"Endereço inválido","Use um endereço completo iniciado por https://.");return;}
                saveSource(a,u);message(a,"Canal salvo","Agora você pode tocar em 'Verificar atualizações'.");
            }).show();
    }
    private static void message(Activity a,String title,String msg){
        if(a.isFinishing())return;
        new AlertDialog.Builder(a).setTitle(title).setMessage(msg==null?"Erro desconhecido.":msg)
            .setPositiveButton("OK",null).show();
    }
}
